All the logos of club be of ratio 1:1 and preferably of png format.
Please take care of the size of the image, as most of time png format images are very huge in size
 
