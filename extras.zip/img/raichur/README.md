You should add all the images here.
Feel free to create sub-folder wherever necessary.

All the images for slider must of the ratio 16:9 and of less size as much as possible.
Also take care of the resolution while compressing remembering the point that these will be full screen slider.

