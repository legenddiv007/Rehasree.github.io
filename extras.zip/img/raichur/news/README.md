All the images must of ratio 3:2 and of very less size.
